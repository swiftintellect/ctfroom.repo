#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>

#include <seccomp.h>

char region[0x1000];

void __attribute__((constructor)) doShiet(){
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
}

void seccomp_rules(){
        scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ALLOW);
        seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execve), 0);
        seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(fork), 0);
        seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execveat), 0);
        seccomp_load(ctx);
        seccomp_release(ctx);
}

void readFlag(){

	memset(region, 0, 0x1000);
	srand(time(NULL));
	long int offset = (rand() % 0xfe0);
	
	const int fd = open("/home/gilbert1/hunter/Y2hhbGwK/flag.txt", O_RDONLY);
	
	if(fd < 0){
		fprintf(stderr, "Create a dummy flag.txt");
		_exit(-1);
	}

	char *buffer = region;
	
	read(fd, (char *) buffer + offset, 0x20);
}

int main(int argc, char **argv){
	char buffer[256];
	readFlag();
	printf("Enter egg-hunter shellcode: ");
	read(0, buffer, sizeof(buffer));
	void (*shell) () = (void (*)) buffer;
	shell();
	return 0;
}
